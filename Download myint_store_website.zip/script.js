document.getElementById("orderForm").addEventListener("submit", function (e) {
  e.preventDefault();
  
  const name = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const address = document.getElementById("address").value;

  const confirmation = `
    ✔ Thank you, ${name}!
    📱 We’ll contact you at ${phone}
    🏠 Address: ${address}
    🛒 အမှာစာလက်ခံရရှိပါသည်။ မကြာမီ ဆက်သွယ်ပေးပါမည်။
  `;
  
  document.getElementById("confirmation").innerText = confirmation;
  document.getElementById("orderForm").reset();
});
